#!/usr/bin/env bash
set -e
python3 -m pip install --upgrade pip
python3 -m pip install -r requirements.txt
python3 -m streamlit run main.py --server.address=0.0.0.0 --server.port=${PORT:-5000} --server.headless=true --server.enableCORS=false --server.enableXsrfProtection=false

# NEUROTRADER PRO

## Overview
This project is a Python Streamlit application for a NEUROTRADER PRO IQ Option trading bot. The main app is served from `main.py`, with trading logic in `bot_engine.py` and license data stored in `licencias.json`.

## Project Structure
- `main.py` - primary Streamlit UI for IQ Option credentials, bot controls, metrics, logs, and trading dashboard.
- `bot_engine.py` - bot state, license validation, analysis/scoring logic, and IQ Option trading engine helpers.
- `pages/1_🔑_Gestor_Licencias.py` - Streamlit multipage admin panel for creating, editing, renewing, deleting, and managing licenses.
- `license_manager.py` - standalone Streamlit license manager entry point.
- `licencias.json` - JSON-backed license store used by the app and admin panel.
- `.streamlit/config.toml` - Streamlit runtime configuration for Replit preview on port 5000.
- `requirements.txt` - Python dependencies, including Streamlit, data/science packages, TA indicators, and IQ Option API from GitHub.

## Runtime Configuration
The Replit workflow `Start application` runs:

```bash
python -m streamlit run main.py --server.address=0.0.0.0 --server.port=5000 --server.headless=true --server.enableCORS=false --server.enableXsrfProtection=false
```

The app must listen on `0.0.0.0:5000` for the Replit web preview. Streamlit CORS/XSRF checks are disabled for development preview compatibility through Replit's iframe proxy.

## Deployment
Deployment is configured as a VM web app using the same Streamlit run command on port 5000. VM deployment is used because the app manages local JSON license data and can run a long-lived bot session from the Streamlit process.

## Trading Rules
- The active strategy registry contains `sop_res`, `pinbar`, `rechazo`, `macd_cross`, `rsi_rebote`, `stoch_cross`, `adx_fuerza`, `vwap_pullback`, and `tendencia_5m`.
- A trade requires at least 2 active strategies to agree in the same direction. A single-strategy signal can also continue only when it reaches score 62+ and then passes the final MFM/CMF/Stochastic/EMA quality filter.
- All approved trades use a 5-minute expiration.
- The scanner filters to 10 fixed forex bases for OTC and normal markets: EURUSD, GBPUSD, USDJPY, AUDUSD, NZDUSD, USDCAD, EURJPY, GBPJPY, XAUUSD, and USDCHF.
- Directional quality uses MFM, CMF-10, Stochastic (14,3,3), and EMA9/EMA21 alignment.
- CALL signals require MFM above the asset threshold, CMF > 0, Stochastic below 80, and EMA9 above EMA21.
- PUT signals require negative MFM beyond the asset threshold, CMF < 0, Stochastic above 20, and EMA9 below EMA21.
- OTC assets use MFM threshold 0.65; normal assets use MFM threshold 0.55.
- Up to 2 trades can run concurrently.
- Martingale is limited to level 1 and is only dispatched when the same MFM/CMF/Stochastic/EMA filter still confirms.
- The daily operation limit is disabled.

## License Manager
- The admin password defaults to `neurotrader2007` if `ADMIN_PASSWORD` is not set.
- The main license manager page supports creating, renewing, listing/exporting, and deleting licenses.
- For production, set `ADMIN_PASSWORD` as an environment secret.

## Notes
- The trading bot requires user-provided IQ Option credentials and a valid license code at runtime.
- The live UI now includes a diagnostic panel below the live log. It surfaces scanner state, latest scanned batch, best candidate, last block reason, last trade attempt, recent diagnostic events, and API-blocked assets.
- The engine records internal reasons when signals do not become trades, including missing candle data, lack of 2-strategy consensus, score below threshold, directional quality filter failures, fresh pre-trade verification blocks, duplicate active assets, and IQ Option order/API errors.
- Assets that repeatedly return no candle data are blocked for the session to reduce repeated IQ Option API errors such as symbols not found in the API constants.
